package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jp.co.internous.dto.LoginDTO;

public class LoginDAO {

	Connection con;
	public String DBuserID;
	public String DBpassword;
	boolean result;

	public boolean select(String userID, String password)throws Exception{

		result = false;
		con=DBconnector.getConnection();

		try{
			String sql = "select * from login where userID=? AND password=?";
			PreparedStatement ps2;
			ps2 = con.prepareStatement(sql);
			ps2.setString(1, userID);
			ps2.setString(2, password);

			System.out.println("loginselect - ps2 -"+ps2);
			ResultSet rs =ps2.executeQuery();

			while(rs.next()){
				result=true;
				System.out.println("login select - while内");
				LoginDTO dto = new LoginDTO();

				dto.setUserID(rs.getString(1));
				DBuserID=dto.getUserID();
				dto.setPassword(rs.getString(2));
				DBpassword=dto.getPassword();
			}//while

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}//finally

		return result;
	}//select

}//class
