package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jp.co.internous.dao.DBconnector;
import jp.co.internous.dto.LoginDTO;
public class LoginDAO {
	Connection con;
	public String DBname;
	public String DBpass;
	boolean result;

	public boolean select(String userid, String password)throws Exception {

		result=false;
		con=DBconnector.getConnection();

		try{
			String sql = "select * from CUSTOMER where USER_ID=? AND PASS=?";
			PreparedStatement ps2;
			ps2 = con.prepareStatement(sql);
			ps2.setString(1,userid);
			ps2.setString(2,password);

			ResultSet rs = ps2.executeQuery();

			while(rs.next()){
				result=true;

				LoginDTO dto = new LoginDTO();

				dto.setUSER_ID(rs.getString(3));
				DBname=dto.getUSER_ID();
				dto.setPASS(rs.getString(4));
				DBpass=dto.getPASS();
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}
		return result;
	}

}
