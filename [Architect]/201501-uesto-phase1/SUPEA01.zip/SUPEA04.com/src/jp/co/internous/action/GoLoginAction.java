package jp.co.internous.action;

import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dto.GoLoginDTO;

import com.opensymphony.xwork2.ActionSupport;

public class GoLoginAction extends ActionSupport {
	public int order_count;
	public int goods_id;
	public static List<GoLoginDTO> LastOrderCheckList = new ArrayList<GoLoginDTO>();
	public String result = SUCCESS;

	public String execute() throws Exception{
		return result;
	}
}

