package jp.co.internous.action;

import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dto.GoCartDTO;

import com.opensymphony.xwork2.ActionSupport;

public class OrderCheckDeleteAction extends ActionSupport {
	public int goods_id;
	public List<GoCartDTO> cartList = new ArrayList<GoCartDTO>();


	public String execute() {
		String result = "success";

		cartList = GoCartAction.getCartList();

		for (int i = 0; i < cartList.size(); i++) {
			if (goods_id == cartList.get(i).getGoods_id()) {

				System.out.println(i + "番目の項目を削除致します");

				cartList.remove(i);
			}
		}

		return result;
	}

	public void setCartList(List<GoCartDTO> cartList) {
		this.cartList = cartList;
	}

	public List<GoCartDTO> getCartList() {
		return cartList;
	}
}
