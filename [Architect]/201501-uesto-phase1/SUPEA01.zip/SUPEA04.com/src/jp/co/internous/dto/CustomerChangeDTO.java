package jp.co.internous.dto;

public class CustomerChangeDTO {
	
	public String Mailad;
	public int postal;
	public String address;
	public int telnumber;
	public String getMailad() {
		return Mailad;
	}
	public void setMailad(String mailad) {
		Mailad = mailad;
	}
	public int getPostal() {
		return postal;
	}
	public void setPostal(int postal) {
		this.postal = postal;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getTelnumber() {
		return telnumber;
	}
	public void setTelnumber(int telnumber) {
		this.telnumber = telnumber;
	}

}
