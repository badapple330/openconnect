package jp.co.internous.action;

import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import jp.co.internous.dao.GoCartDAO;
import jp.co.internous.dto.GoCartDTO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class Go2CartAction extends ActionSupport implements SessionAware{

	public List<GoCartDTO> cartList = new ArrayList<GoCartDTO>();
	public List<GoCartDTO> checkList = new ArrayList<GoCartDTO>();
	public int goods_id;
	public Map<String,Object> sessionMap;

	public String execute() throws Exception{
	//何も無いのに成功はおかしいからエラー
	String	result=ERROR;

	GoCartDAO dao =new GoCartDAO();

	String uuid=(String) sessionMap.get("UUID");
	String macadd=getMacAddr();

	if(dao.select(uuid)){
		cartList.addAll(dao.getCartList());
		result = SUCCESS;
	}
return result;

	}
	public String getMacAddr() throws SocketException{
        String s = null;
	    Enumeration<NetworkInterface> nics =
	        NetworkInterface.getNetworkInterfaces();
	    while(nics.hasMoreElements()){
	        NetworkInterface nic = nics.nextElement();
	        s = "";
	        byte[] hardwareAddress = nic.getHardwareAddress();
	        if(hardwareAddress != null){
	            for(byte b : hardwareAddress){
	                s += String.format("%02X ", b);
	            }
	        }

	        if(s!=""){
	        	break;
	        }
	    }
	    return s;
}

	public List<GoCartDTO> getCheckList() {
		return checkList;
	}
	public void setCheckList(List<GoCartDTO> checkList) {
		this.checkList = checkList;
	}
	public List<GoCartDTO> getCartList() {
		return cartList;
	}

	public void setCartList(List<GoCartDTO> cartList) {
		this.cartList = cartList;
	}
	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}





}
