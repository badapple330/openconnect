package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dto.GoCartDTO;

public class GoCartDAO {
	Connection con;
	boolean action;
	public int goods_id;
	public List<GoCartDTO> cartList = new ArrayList<GoCartDTO>();


	public boolean insert(int goods_id, String macadd)throws Exception{
		action=false;
		con=DBconnector.getConnection();
		try{
			String sql="insert into cart(goods_name,session_ID,Order_Count,Price,TOTAL_AMOUNT) value(?,?,1,0,0);";

			PreparedStatement ps;
			ps=con.prepareStatement(sql);
			ps.setInt(1,goods_id);
			ps.setString(2,macadd);

			System.out.println("GoCartDAO - goods_id - "+goods_id);

			int count = ps.executeUpdate();
			System.out.println("GoCartDAO - Query実行");

			if(count>0){
				action=true;
				System.out.println("GoCartDAO - action - "+action);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}

		return action;
	}

	public  boolean select(String session_id){
		action=false;
		con=DBconnector.getConnection();
		try{
			String sql="select session_id,goods.goods_id,sum(order_count),goods.price,goods.goods_name from cart inner join goods on cart.goods_name=goods.goods_id where session_id=? group by cart.goods_name;";

			PreparedStatement ps;
			ps=con.prepareStatement(sql);
			ps.setString(1,session_id);


			//System.out.println("GoCartDAO - goods_id - "+session_id);

			ResultSet rs =ps.executeQuery();
			while(rs.next() ){
				action = true;

				GoCartDTO dto = new GoCartDTO();
				//dto.setGoods_id(rs.getInt(4));
				dto.setGoods_id(rs.getInt(2));
				System.out.println("goods_name-gocartdao:"+rs.getInt(2));
				//dto.setStock(rs.getInt(6));
				dto.setPrice(rs.getInt(4));
				//dto.setKcal(rs.getInt(8));
				dto.setOrder_count(rs.getInt(3));
				dto.setSession_id(rs.getString(1));
				dto.setGoods_name(rs.getString(5));

				dto.setTotal_amount(rs.getInt(4)*rs.getInt(3));
				cartList.add(dto);
			}
			System.out.println("GoCartDAO - Query実行");


		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return action;
}
	public int select2(String session_id){
		int result=0;
		con=DBconnector.getConnection();
		try{
			String sql="select sum(ORDER_COUNT*goods.price) from cart left join goods on cart.GOODS_NAME=goods.GOODS_ID group by SESSION_ID having SESSION_ID=?;";

			PreparedStatement ps;
			ps=con.prepareStatement(sql);
			ps.setString(1,session_id);


			System.out.println("GoCartDAO - goods_id - "+session_id);

			ResultSet rs =ps.executeQuery();
			if(rs.next() ){
				result=rs.getInt(1);
			}
			System.out.println("GoCartDAO - Query実行");


		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return result;
	}

	public int delete(String session_id){
		con=DBconnector.getConnection();
		int count = 0;
		try{
			String sql="delete from cart where session_id=?";

			PreparedStatement ps;
			ps=con.prepareStatement(sql);
			ps.setString(1,session_id);


			System.out.println("GoCartDAO - goods_id(session) - "+session_id);

			count = ps.executeUpdate();
			System.out.println("GoCartDAO - Query実行");

			if(count>0){

				System.out.println("GoCartDAO - action - "+action);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
		}

		return count;
	}


	public List<GoCartDTO> getCartList() {
		return cartList;
	}


	public void setCartList(List<GoCartDTO> cartList) {
		this.cartList = cartList;
	}





}
