drop database if exists prototype;

create database if not exists prototype;
use prototype;

drop table if exists login;

create table if not exists login(userID varchar(50),password varchar(50));
insert into login(userID,password)values("test","test");
insert into login(userID,password)values("test1","test1");

drop table if exists prototype;

create table prototype (
  id int(99) NOT NULL AUTO_INCREMENT,
  item varchar(255) NOT NULL,
  number int(99) NOT NULL,
  PRIMARY KEY (ID),
  UNIQUE KEY (item)
);

insert into prototype(id,item,number)value(1,"�A�C�e��1",10);
insert into prototype(id,item,number)value(2,"�A�C�e��2",10);
insert into prototype(id,item,number)value(3,"�A�C�e��3",10);
insert into prototype(id,item,number)value(4,"�A�C�e��4",10);
insert into prototype(id,item,number)value(5,"�A�C�e��5",10);

