package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jp.co.internous.dto.Customer_OKDTO;

public class Customer_OKDAO {

	Connection con;

	public String userid;
	public String password;
	public String DBuserid;
	public String DBpassword;

	boolean result;

	public boolean select(String userid, String password) throws Exception{
		System.out.println("select - メソッド実行");
		result = false;

		con = DBconnector.getConnection();

		try{
			String sql = "select * from customer";

			PreparedStatement ps;
			ps = con.prepareStatement(sql);
			System.out.println("select - ps2 - "+ ps);

			ResultSet rs = ps.executeQuery();
			System.out.println("select - sql実行");

			while(rs.next()){

				result = true;

				Customer_OKDTO dto = new Customer_OKDTO();

				dto.setUserid(rs.getString(3));
				DBuserid = dto.getUserid();

				dto.setPassword(rs.getString(4));
				DBpassword = dto.getPassword();
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}

		System.out.println("select - return - "+ result);
		return result;
	}

}
