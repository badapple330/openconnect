package jp.co.internous.action;

import com.opensymphony.xwork2.ActionSupport;

public class GoCustomer_infoAction extends ActionSupport{
	public  String execute(){
		return SUCCESS;
	}//execute

}
