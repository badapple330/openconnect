package jp.co.internous.action;

import jp.co.internous.dao.PrototypeDAO;

import com.opensymphony.xwork2.ActionSupport;

public class InsertAction extends ActionSupport{

	private String insertitem;
	private int insertnumber;
	int count;
	public String action=ERROR;

	public String execute() throws Exception{
		System.out.println("■InserActiont内");

		System.out.println("Insert - JSPからの値 - "+insertitem +"/"+insertnumber);

		PrototypeDAO dao = new PrototypeDAO();
		System.out.println("■PrototypeDAOに突入");

		count=dao.insert(insertitem,insertnumber);

		if(count>0){
			action=SUCCESS;
		}

		return action;
	}

	public String getInsertitem(){
		return insertitem;
	}
	public void setInsertitem(String insertitem){
		this.insertitem=insertitem;
	}

	public int getInsertnumber(){
		return insertnumber;
	}
	public void setInsertnumber(int insertnumber){//変更
		this.insertnumber=insertnumber;//変更
	}

}
