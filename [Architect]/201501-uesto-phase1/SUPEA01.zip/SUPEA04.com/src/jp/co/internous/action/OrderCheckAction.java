package jp.co.internous.action;

import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dao.TESTOrderCheckDAO;
import jp.co.internous.dto.OrderCheck_DTO;

import com.opensymphony.xwork2.ActionSupport;



public class OrderCheckAction extends ActionSupport{

	public int order_count;
	public int goods_id;
	public static List<OrderCheck_DTO> checkList = new ArrayList<OrderCheck_DTO>();
	public String  result=ERROR;

	public String execute() throws Exception {
		System.out.println("OrderCheckAction - in");
		System.out.println("OrderCheckAction - order_count - "+order_count);

		TESTOrderCheckDAO dao = new TESTOrderCheckDAO();
		System.out.println("DAOに突入");
		boolean rsDAO = dao.select(goods_id,result, order_count, goods_id, goods_id);

		if (rsDAO) {
			checkList.addAll(dao.getCheckList());
			System.out.println("OrderCheckAction - checkList - " + checkList);

			result = SUCCESS;

		}
		return result;
	}

	public int getGoods_id() {
		return goods_id;
	}

	public void setGoods_id(int goods_id){
		this.goods_id = goods_id;
	}

	public static List<OrderCheck_DTO> getCheckList() {
		return checkList;
	}

	public static void setCheckList(List<OrderCheck_DTO> checkList) {
		OrderCheckAction.checkList = checkList;
	}








	}