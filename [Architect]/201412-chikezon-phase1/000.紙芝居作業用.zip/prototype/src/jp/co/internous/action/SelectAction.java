package jp.co.internous.action;

import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dao.PrototypeDAO;
import jp.co.internous.dto.PrototypeDTO;

import com.opensymphony.xwork2.ActionSupport;

public class SelectAction extends ActionSupport{

	public List<PrototypeDTO> itemList1 = new ArrayList<PrototypeDTO>();
	public String result = ERROR;

	public String execute() throws Exception {

	String item;

	PrototypeDAO dao = new PrototypeDAO();
	boolean resultDAO = dao.select();
	System.out.println("resultDAO="+resultDAO);
	System.out.println("PrototypeDAO.selectからSelectActionに復帰");
	if(resultDAO){
		System.out.println("if文に入ってる");
		itemList1.addAll(dao.getItemList1());//日付、出勤、退勤時間のデータ
		result = SUCCESS;
		System.out.println("itemList1"+itemList1);
	}
	return result;
	}

}
