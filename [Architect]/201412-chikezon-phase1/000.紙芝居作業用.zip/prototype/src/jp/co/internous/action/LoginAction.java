package jp.co.internous.action;

import java.util.Map;

import jp.co.internous.dao.LoginDAO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport implements SessionAware{

	public String userID;
	public String password;
	public String result;
	public Map<String, Object> sessionMap;

	public String execute()throws Exception{
		System.out.println("loginaction - 中");
		result = ERROR;
		try{

		LoginDAO dao = new LoginDAO();

		if(dao.select(userID, password)){
			result=SUCCESS;
			System.out.println("loginAction - dao - チェックOK");
			sessionMap.put("USERNAME",dao.DBuserID);
			System.out.println("--------------sessionUSERNAME-----------"+sessionMap.get("USERNAME"));

		}//if

		}catch(Exception e){
			e.printStackTrace();
		}//catch
		System.out.println("loginAction - return - "+result);
		return result;

	}//execute

	public String setUserID(String userID){
		return this.userID = userID;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	public void setSession(Map<String, Object> sessionMap) {
		this.sessionMap = sessionMap;
	}


}//class
