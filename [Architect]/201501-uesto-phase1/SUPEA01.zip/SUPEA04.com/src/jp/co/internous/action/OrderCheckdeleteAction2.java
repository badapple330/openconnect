package jp.co.internous.action;
import jp.co.internous.dao.TESTOrderCheckDAO;

import com.opensymphony.xwork2.ActionSupport;


	public class OrderCheckdeleteAction2 extends ActionSupport{

		public int goods_id;
		public String session_id;
		int count;
		public String action=ERROR;

		public String execute()throws Exception{
			System.out.println("session"+session_id+"goods"+goods_id);

			TESTOrderCheckDAO dao=new TESTOrderCheckDAO();
			System.out.println("TESTOrderCheckDAO突入");

			count=dao.delete(goods_id,session_id);
			if(count>0){
				action=SUCCESS;
			}

			return action;
		}

		public int getGoods_id(){
			return goods_id;
		}

		public void setGoods_id(int goods_id) {
			this.goods_id = goods_id;
		}

		public String getSession_id() {
			return session_id;
		}

		public void setSession_id(String session_id) {
			this.session_id = session_id;
		}



	}



