package jp.co.internous.action;

import java.util.Map;

import jp.co.internous.dao.TESTOrderCheckDAO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;


public class OrderCheckAction2 extends ActionSupport implements SessionAware{

	public int goods_id;
	public int order_count;
	//public String goods_name;
	int count;
	public String action=ERROR;
	public Map<String, Object> sessionMap;

	public String execute()throws Exception{
		System.out.println("OrderCheckAction2内");

		System.out.println("OrderCheck-JSPからの値-"+goods_id+"/"+order_count);

		TESTOrderCheckDAO dao=new TESTOrderCheckDAO();
		System.out.println("TESTOrderCheckDAOに突入");
		String uuid = (String) sessionMap.get("UUID");

		count=dao.update(goods_id,order_count,uuid);

		if(count>0){
			action=SUCCESS;
		}

		System.out.println("result:"+action);
		return action;
	}
	public int getgoods_id(){
		return goods_id;
	}

	public void setgoods_id(int goods_id){
		this.goods_id=goods_id;
	}

	public int getOrder_count(){
		return order_count;
	}

	public void setUOrder_count(int Order_count){
		this.order_count=Order_count;
	}

	public Map<String, Object> getSessionMap() {
		return sessionMap;
	}

	@Override
	public void setSession(Map<String, Object> sessionMap) {
		// TODO 自動生成されたメソッド・スタブ
		this.sessionMap = sessionMap;
	}
}
