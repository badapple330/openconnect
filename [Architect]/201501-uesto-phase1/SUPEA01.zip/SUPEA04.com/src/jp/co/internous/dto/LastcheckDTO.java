package jp.co.internous.dto;



public class LastcheckDTO {

	public int session_id;

	public String good_name;

	public int order_count;

	public int price;





	public int getSession_id() {
		return session_id;
	}

	public int getOrder_count() {
		return order_count;
	}

	public void setSession_id(int session_id) {
		this.session_id = session_id;
	}

	public String getGood_name() {
		return good_name;
	}

	public void setGood_name(String good_name) {
		this.good_name = good_name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setOrder_count(int order_count) {
		this.order_count= order_count;
	}
}
