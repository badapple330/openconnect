/*package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import jp.co.internous.action.OrderCheckAction;
import jp.co.internous.dto.OrderCheck_DTO;

public class EndDAO {

	Connection con;
	public List<OrderCheck_DTO> cartList=new ArrayList<OrderCheck_DTO>();

	public int insert(String userid,String goods_name,int order_count) throws Exception {
		cartList=OrderCheckAction.cartList;
		System.out.println("EndDAO - insert - in");
		con = DBconnector.getConnection();
		int rscount = 0;
		try {

			String sql = "insert into order_info(id,good_name,order_count) values(?,?,?)";

			PreparedStatement ps2;
			ps2 = con.prepareStatement(sql);
			ps2.setString(1,userid);
			ps2.setString(2,goods_name);
			ps2.setObject(3,order_count);


			rscount = ps2.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.close();
		}

		return rscount;
	}
}
*/