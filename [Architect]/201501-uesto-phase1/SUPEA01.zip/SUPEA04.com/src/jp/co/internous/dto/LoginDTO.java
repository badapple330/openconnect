package jp.co.internous.dto;

public class LoginDTO {
	 public String CUSTOMER_NAME;
	 public String USER_ID;
	 public String PASS;
	 public String MAILAD;
	 public int POSTCODE;
	 public String ADDRESS;
	 public int TELNUMBER;

public String getCUSTOMER_NAME() {
	return CUSTOMER_NAME;
}
public void setCUSTOMER_NAME(String cUSTOMER_NAME) {
	CUSTOMER_NAME = cUSTOMER_NAME;
}
public String getUSER_ID() {
	return USER_ID;
}
public void setUSER_ID(String uSER_ID) {
	USER_ID = uSER_ID;
}
public String getPASS() {
	return PASS;
}
public void setPASS(String pASS) {
	PASS = pASS;
}
public String getMAILAD() {
	return MAILAD;
}
public void setMAILAD(String mAILAD) {
	MAILAD = mAILAD;
}
public int getPOSTCODE() {
	return POSTCODE;
}
public void setPOSTCODE(int pOSTCODE) {
	POSTCODE = pOSTCODE;
}
public String getADDRESS() {
	return ADDRESS;
}
public void setADDRESS(String aDDRESS) {
	ADDRESS = aDDRESS;
}
public int getTELNUMBER() {
	return TELNUMBER;
}
public void setTELNUMBER(int tELNUMBER) {
	TELNUMBER = tELNUMBER;
}

}
