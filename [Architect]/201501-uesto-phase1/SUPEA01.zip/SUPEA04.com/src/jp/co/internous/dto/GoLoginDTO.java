package jp.co.internous.dto;

public class GoLoginDTO {

	private String goods_name;
	private int sales_numbers ;
	private int price;
	private int goods_id;
	private int order_count;
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public int getSales_numbers() {
		return sales_numbers;
	}
	public void setSales_numbers(int sales_numbers) {
		this.sales_numbers = sales_numbers;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(int goods_id) {
		this.goods_id = goods_id;
	}
	public int getOrder_count() {
		return order_count;
	}
	public void setOrder_count(int order_count) {
		this.order_count = order_count;
	}


}
