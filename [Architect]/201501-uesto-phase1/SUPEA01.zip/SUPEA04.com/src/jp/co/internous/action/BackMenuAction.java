
package jp.co.internous.action;

import com.opensymphony.xwork2.ActionSupport;

public class BackMenuAction extends ActionSupport {


	public String execute() {
		String ret = "success";
		return ret;
	}
}
