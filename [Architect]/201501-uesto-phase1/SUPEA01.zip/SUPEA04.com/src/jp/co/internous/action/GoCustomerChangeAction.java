package jp.co.internous.action;

import java.util.Map;

import jp.co.internous.dao.GoCustomerChangeDAO;

import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

public class GoCustomerChangeAction extends ActionSupport implements SessionAware{


	public String mailad;
	public String postcode;
	public String address;
	public String telnumber;
	public String result;
	public Map<String,Object> session;

	public String execute()throws Exception{
		System.out.println("GCC-中");
		result=ERROR;
		try{
			GoCustomerChangeDAO dao=new GoCustomerChangeDAO();
			// sessionからUser_idを取り出す
			String user_id = session.get("USERID").toString();
			System.out.println("USER_IDは"+user_id);
			System.out.println("SELECT実行");
			if (dao.select(user_id,mailad,postcode,address,telnumber)){
				System.out.println("SELECT実行完了。登録していくよ");
				mailad = dao.DBmailad;
				System.out.println(mailad);
				postcode=dao.DBpostcode;
				System.out.println(postcode);
				address=dao.DBaddress;
				System.out.println(address);
				telnumber=dao.DBtelenumber;
				System.out.println(telnumber);

				result=SUCCESS;
				System.out.println("GCC-dao-チェックok");

			}
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("GCCAction-return-"+result);
		return result;
	}


	public String getMailad() {
		return mailad;
	}
	public void setMailad(String mailad) {
		this.mailad = mailad;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTelnumber() {
		return telnumber;
	}
	public void setTelnumber(String telnumber) {
		this.telnumber = telnumber;
	}


	public Map<String, Object> getSession() {
		return session;
	}


	@Override
	public void setSession(Map<String, Object> session) {
		this.session = session;

	}


}
