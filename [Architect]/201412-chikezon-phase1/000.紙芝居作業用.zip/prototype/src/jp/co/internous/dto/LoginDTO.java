package jp.co.internous.dto;

public class LoginDTO {

	public String userID;
	public String password;

	public void setUserID(String userID){
		this.userID=userID;
	}

	public String getUserID(){
		return userID;
	}

	public void setPassword(String password){
		this.password=password;
	}

	public String getPassword(){
		return password;
	}
}
