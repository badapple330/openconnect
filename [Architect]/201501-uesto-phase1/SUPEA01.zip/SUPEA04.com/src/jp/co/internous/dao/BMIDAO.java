package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jp.co.internous.dto.BMIDTO;



public class BMIDAO {

	Connection con;
	boolean action;

	public List<BMIDTO> pickupList=new ArrayList<BMIDTO>();

	public boolean select(int kcal)throws Exception{
		System.out.println("selectメソッド実行");
		action=false;
		con=DBconnector.getConnection();

		try{
		String sql="select * from GOODS where kcal = ?";

		PreparedStatement ps;
		ps= con.prepareStatement(sql);

		ps.setInt(1,kcal);

		ResultSet rs=ps.executeQuery();
		System.out.println("select-sql実行");

		while(rs.next()){
			action=true;
			System.out.println("BMIDAO - while");
			BMIDTO dto=new BMIDTO();
			dto.setGoods_id(rs.getInt(1));
			dto.setGoods_name(rs.getString(2));
			dto.setStock(rs.getInt(3));
			dto.setPrice(rs.getInt(4));
			dto.setKcal(rs.getInt(5));
			pickupList.add(dto);

			System.out.println("BMIDAO - while - list "+pickupList);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}
		return action;

	}

	public List<BMIDTO> getPickupList() {
		return pickupList;
	}

	public void setPickupList(List<BMIDTO> pickupList) {
		this.pickupList = pickupList;
	}



}
