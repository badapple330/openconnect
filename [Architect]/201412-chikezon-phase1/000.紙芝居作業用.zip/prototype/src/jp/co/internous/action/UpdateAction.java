package jp.co.internous.action;

import jp.co.internous.dao.PrototypeDAO;

import com.opensymphony.xwork2.ActionSupport;

public class UpdateAction extends ActionSupport{


	private int updateid;
	private int updatenumber;
	int count;
	public String action=ERROR;

	public String execute() throws Exception{
		System.out.println("■UpdateAction内");

		System.out.println("Update - JSPからの値 - "+updateid +"/"+updatenumber);

		PrototypeDAO dao = new PrototypeDAO();
		System.out.println("■PrototypeDAOに突入");

		count=dao.update(updateid, updatenumber);

		if(count>0){
			action=SUCCESS;
		}

		return action;
	}

	public int getUpdateid(){
		return updateid;
	}
	public void setUpdateid(int updateid){
		this.updateid=updateid;
	}
	public int getUpdatenumber(){
		return updatenumber;
	}
	public void setUpdatenumber(int updatenumber){
		this.updatenumber=updatenumber;
	}
}
