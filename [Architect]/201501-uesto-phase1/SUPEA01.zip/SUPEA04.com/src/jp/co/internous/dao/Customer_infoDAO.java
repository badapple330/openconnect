package jp.co.internous.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jp.co.internous.dto.Customer_infoDTO;

public class Customer_infoDAO {


	Connection con;
	boolean result;


	public int insert(String insertname,String insertuserid,String insertpassword,
			String insertmailad,int insertpostal,String insertaddress,
			String inserttelnum) throws Exception{

		System.out.println("■insert突入");
		con = DBconnector.getConnection();
		int rscount = 0;

		try{

			String sql = "insert into customer(customer_name,user_id,pass,mailad,postcode,address,telnumber) value(?,?,?,?,?,?,?)";

			PreparedStatement ps2;
			ps2 = con.prepareStatement(sql);

			ps2.setString(1, insertname);
			ps2.setString(2, insertuserid);
			ps2.setString(3, insertpassword);
			ps2.setString(4, insertmailad);
			ps2.setInt(5, insertpostal);
			ps2.setString(6, insertaddress);
			ps2.setString(7, inserttelnum);

			rscount = ps2.executeUpdate();

			if(rscount > 0){
				System.out.println("insert - インサート完了");
			}else{
				System.out.println("insert - インサート失敗");
			}


		}catch(Exception e){

		}finally{
			con.close();
		}
		return rscount;
	}//insert


	public boolean select(String name, String userid, String password, String mailad, int postal, String address, String telnum) throws Exception{
		System.out.println("select - メソッド実行");

		result = false;
		con = DBconnector.getConnection();

		try{

			String sql = "select * from customer";

			PreparedStatement ps;
			ps = con.prepareStatement(sql);
			System.out.println("select - ps - "+ ps);

			ResultSet rs = ps.executeQuery();
			System.out.println("select - sql実行");

			while(rs.next()){
				result = true;

				Customer_infoDTO dto = new Customer_infoDTO();

				dto.setName(rs.getString(2));
				dto.setUserid(rs.getString(3));
				dto.setPassword(rs.getString(4));
				dto.setMailad(rs.getString(5));
				dto.setPostal(rs.getInt(6));
				dto.setAddress(rs.getString(7));
				dto.setTelnum(rs.getString(8));

			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			con.close();
		}
		System.out.println("select - return - "+ result);
		return result;

	}//select



}//class
