package jp.co.internous.action;

import jp.co.internous.dao.PrototypeDAO;

import com.opensymphony.xwork2.ActionSupport;

public class DeleteAction extends ActionSupport{

	private int delid;
	int count;
	public String action=ERROR;

	public String execute() throws Exception{

			System.out.println("■DeleteAction内");

		PrototypeDAO dao = new PrototypeDAO();
			System.out.println("■PrototypeDAOに突入");

		count=dao.delete(delid);
		if(count>0){
			action=SUCCESS;
		}


		return action;
	}

	public int getDelid() {
		return delid;
	}

	public void setDelid(int delid) {
		this.delid = delid;
	}



}